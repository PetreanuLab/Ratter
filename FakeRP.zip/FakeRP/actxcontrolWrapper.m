%actxcontrolWrapper.m   [out] = actxcontrolWrapper(varargin)
%
% Takes two possible actions, depending on the value of the global variable
% 'fake_rp_box':
%
%   - If fake_rp_box doesn't exist, is empty, or is not 1, then calls
%          out = actxcontrolWrapper(args); 
%        with args being whatever was passed to it.
%
%   - If fake_rp_box == 1, then interprets the first three args as 
%        name, pos, handle, and ...
%

function [out] = actxcontrolWrapper(varargin)

global fake_rp_box;
global FakeActiveXObjects;

if length(varargin)<1, error('Need at least one argument'); end;
    
if isempty(fake_rp_box) | fake_rp_box ~= 1,
    argstr = []; for i=1:length(varargin)-1,
        argstr = [argstr 'varargin{' num2str(i) '}, '];
    end;
    argstr = [argstr 'varargin{' num2str(length(varargin)) '}'];
    out = (['actxcontrol(' argstr ');']);
    return;
else
    if length(varargin) < 3, error('Need name, pos, handle as args'); end;
    name = varargin{1}; pos = varargin{2}; fighandle = varargin{3};
    if isempty(FakeActiveXObjects), 
        FakeActiveXObjects = {'xhandle', 'name', 'pos', 'fighandle', 'rp_machine'}; 
    end;

    % otherhandles = getvals(FakeActiveXObjects, 'xhandle');
    % newhandle = max(otherhandles)+1;
    newhandle = num2str(size(FakeActiveXObjects,1));
    FakeActiveXObjects = [FakeActiveXObjects ; {newhandle name pos fighandle ''}];
    out = newhandle;
    return;
end;
