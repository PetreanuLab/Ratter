function [] = SoftTrg1(lh1)
% If running, trigger a TimesUp event

    TimesUp(lh1);

    
    