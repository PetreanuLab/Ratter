function [] = SoftTrg(lh1, trigger_number)

    eval(['SoftTrg' num2str(trigger_number) '(lh1)']);
    return;
    