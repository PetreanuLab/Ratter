function [] = save_mylh1(lh1)

    global private_lunghao1_list;
    private_lunghao1_list{lh1.list_position} = lh1;
    