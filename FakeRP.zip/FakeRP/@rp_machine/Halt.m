function [rp] = Halt(rp)

rp.halt = 1;
