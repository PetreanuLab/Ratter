function [rp] = Run(rp)

rp.halt = 0;
