%invokeWrapper.m   [out] = invokeWrapper(axhandle, varargin)
%
% Takes two possible actions, depending on the value of the global variable
% 'fake_rp_box':
%
%   - If fake_rp_box doesn't exist, is empty, or is not 1, then calls
%          out = invoke(axhandle, args); 
%        with args being whatever was passed to it. axhandle should be
%        an ActiveX ID as retruned by actxcontrol.
%
%   - If fake_rp_box == 1, then ...
%

function [out] = invokeWrapper(varargin)

global fake_rp_box;
global FakeActiveXObjects;

if length(varargin)<1, error('Need at least one argument'); end;
    
if isempty(fake_rp_box) | fake_rp_box ~= 1,
    argstr = []; for i=1:length(varargin)-1,
        argstr = [argstr 'varargin{' num2str(i) '}, '];
    end;
    argstr = [argstr 'varargin{' num2str(length(varargin)) '}'];
    out = (['invoke(' argstr ');']);
    return;
else
    if length(varargin) < 2, error('Need at least handle, command as args'); end;
    xhandle = varargin{1}; command = varargin{2};
    mid = find(strcmp(FakeActiveXObjects(:,findRnum(FakeActiveXObjects, 'xhandle')), xhandle));
    if isempty(mid), error('Couldn''t find the rp machine with this xhandle'); end;
    machine = FakeActiveXObjects{mid, findRnum(FakeActiveXObjects, 'rp_machine')};
   
    if isempty(machine),
        switch command,
            case {'DefID' 'Halt' 'ClearCOF' 'ConnectRP2'},
                out = 1; return;
            case 'LoadCOF',
                switch nopath(varargin{3})
                    case {'RP2Box.rco' 'RM1Box.rco'}
                        machine = lunghao1;
                        setup_lunghao1_gui(machine);
                        % Look for a lunghao2 to connect to 
                        allmachines = FakeActiveXObjects(2:end, findRnum(FakeActiveXObjects, 'rp_machine'));
                        for othermachine = allmachines',
                            if isa(othermachine{1}, 'lunghao2')
                                set(machine, ...
                                    'aoutchange_callback', {'lh1_to_lh2_connection_and_lh1_aout_gui', othermachine{1}});
                            end;
                        end;
                        
                    case {'2SoundRP2_2.rco' '2SoundRM1_2.rco'}
                        machine = lunghao2;
                        % Look for a lunghao1 to connect to 
                        allmachines = FakeActiveXObjects(2:end, findRnum(FakeActiveXObjects, 'rp_machine'));
                        for othermachine = allmachines',
                            if isa(othermachine{1}, 'lunghao1')
                                set(othermachine{1}, ...
                                    'aoutchange_callback', {'lh1_to_lh2_connection_and_lh1_aout_gui', machine});
                            end;
                        end;
                        
                    otherwise
                        error(['FakeRP: Don''t know how to LoadCOF a virtual ' nopath(varargin{3})]);
                end;
                FakeActiveXObjects{mid, findRnum(FakeActiveXObjects, 'rp_machine')} = machine;
                out=1; return;
                
            otherwise
                error(['Fake RP: Don''t know how to execute ' command ' on an empty machine']);
        end;
    else
        command = varargin{2};
        callstr = [command '(machine']; for i=3:length(varargin)-1,
            callstr = [callstr ', varargin{' num2str(i) '} '];
        end;
        if length(varargin)>=3, callstr = [callstr ', varargin{' num2str(length(varargin)) '});']; 
        else callstr = [callstr ');'];
        end;
        % callstr,
        switch command
            case {'GetTagVal' 'ReadTagVEX' 'ReadTagVex', 'SetTagVal', 'WriteTagV'},
                out = eval(callstr);
            otherwise
                eval(callstr);
        end;
    return;

    end;    
    
    return;
end;


% ---------------

function [id] = findRnum(cellname, str)
    id = find(strcmp(cellname(1,:), str));
    return;
    
