function [] = Halt(lh1)
    
