function [] = SoftTrg2(lh1)
% Doesn't do anything here...

warning('Matlab implementation cannot stop sounds while they are running...\n');
