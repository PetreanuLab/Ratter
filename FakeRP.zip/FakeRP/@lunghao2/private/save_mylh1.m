function [] = save_mylh1(lh1)

    global private_lunghao2_list;
    private_lunghao2_list{lh1.list_position} = lh1;
    