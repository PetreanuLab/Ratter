function [] = Run(lh1)

   