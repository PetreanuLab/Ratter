function [] = lunghao1_dio_bypass1_timer_callback(obj, event, lh1)

    set(lh1, 'DIO_Bypass1Active', 0);

    